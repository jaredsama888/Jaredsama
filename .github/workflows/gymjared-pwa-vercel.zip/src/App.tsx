function App() {
  return (
    <div className="App">
      <h1>Bienvenido a GymJARED</h1>
      <p>Tu PWA está funcionando correctamente.</p>
    </div>
  )
}

export default App